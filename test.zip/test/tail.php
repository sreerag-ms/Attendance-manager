<!DOCTYPE html>
<html>
 <link rel="stylesheet" type="text/css" href="style1.css">
  <link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro|Play" rel="stylesheet">
<head>
	<title></title>

	<?php
include('db.php');
session_start();
$id=(int)$_SESSION['id'];
$val=$_SESSION['choice'];
#var_dump($id);
function alert(){

echo "<script type='text/javascript'>";
echo "alert('Attendance updated.');";
echo "</script>";
}
?>
<?php
$tattended =(int)@$_POST['attended'];
$tmissed = (int)@$_POST['missed'];
$ttotal=$tmissed+$tattended;
$submit = @$_POST['submit'];
$query2 = "SELECT * FROM data WHERE id='$id' AND code='$val'";

$result=mysqli_query($db,$query2);
if($submit){
	if($arr=mysqli_fetch_row($result));
		{

		$total=(int)$arr['4'];
		$attended=(int)$arr['3'];
		$ftotal=$ttotal+$total;
		$fattended=$tattended+$attended;
		$query1 = "UPDATE `data` SET `attendance` = '$fattended', `total` = '$ftotal' WHERE `data`.`id` = $id AND `data`.`code` = '$val'";
		$result2=mysqli_query($db,$query1) or die("couldnt update");
		if($result2)
		{
		alert();
		header( "refresh:0; url=update.php" );
    	exit();
	}
	else
		echo "failed";


	}}
	




?>
</DIV>
</head>
<body>
	<header>
		<nav>
			<div class="row blank">
	
			</div>
		</nav>
		<div class="cont">
		
			<form method="post" class ="form">
				<h3><br>Update your attendance : <?php echo "$val"; ?></h3>
		Hours Missed &nbsp;&nbsp;&nbsp;&nbsp;: <input class="txt" type="text"  name="missed" placeholder="Hours missed" value="0"><br>
      	Hours Attended :  <input class="txt" type="text" name="attended" placeholder="Hours attended"  value="0"><br>
      
			<input type="submit" class="btn1" name="submit" value="UPDATE">
			
			</form>
		</div>
	</header>

</body>
</html>
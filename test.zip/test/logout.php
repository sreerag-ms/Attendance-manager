<html>
<head>
	<link rel="stylesheet" type="text/css" href="style2.css">
	<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Maven+Pro|Play" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web">
	<?php 
		include('db.php');
		session_start();
		$name = $_SESSION['fullname'];
		echo "<title>$name</title>";
		$id = $_SESSION['id'];
		$query1 = "SELECT * FROM data WHERE id='$id'";
		$result=mysqli_query($db,$query1);




	 ?>
</head>
<body>
	<header>
		<nav>
			<div class="row blank">
		<?php
		$logout = @$_POST['logout'];
		if($logout)
		{
		session_destroy();
		header("location:index.php"); 
		exit();
		}
		?>		
			</div>
		</nav>
					
		<div class="cont">
			<?php echo "<h3>Hello $name</h3><br>"; ?>

			<?php
			if($result)
			{	
				$i=0;
				while($arr=mysqli_fetch_row($result))
				{	

					$i++;
					$extra=0;
					$att=$arr['3'];
					$total=$arr['4'];
					$course=$arr['2'];
					if($total!=0){
						$perc=round(($att/$total)*100,2);
						echo "#$course - - $perc% ,  $att out of  $total classes <br>";
						}					
					else{
						$perc=-1;
						echo " #$course - - Please attend the class for the first time<br>";
						}
					
					if($perc<75 && $perc>=0)
					{
						while($perc<75)
						{
							$att=$att+1;
							$total=$total+1;
							$perc=($att/$total)*100;
							$extra=$extra+1;
						}
					echo "<font color='#aa0000' >Attend $extra more to hours reach 75%</font><br><br>";

					}
					else
						echo "<br>";

				}
			}
			if($i==0){
				$j='disabled';
				echo "No courses, Add courses for the attendance";
			}
			else{
				$j='enabled';
			}


			 ?>



		</div>
		<form method="post" class ="main_nav">
			<input type="submit" name="add" class="btn1" value="Add Course">
      		<input type="submit" name="update" class="btn1" value="Update" <?php echo $j ?>>
			<input type="submit" class="btn1" name="logout" value="Logout">
		<?php

		$course = @$_POST['add'];
		$update = @$_POST['update'];

		if($course)
		{
		header("location:add.php"); 
		exit();

		}
		if($update)
		{
		header("location:update.php"); 
		exit();
		}
	?>
			
			</form>
	</header>
</d>
</body>
</html>

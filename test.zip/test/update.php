<html>
<head>
	<link rel="stylesheet" type="text/css" href="styleupdate.css">
	<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Maven+Pro|Play" rel="stylesheet">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web">
	<?php 
		include('db.php');
		session_start();
		$name = $_SESSION['fullname'];
		echo "<title>$name</title>";
		$id = $_SESSION['id'];
		$query1 = "SELECT * FROM data WHERE id='$id'";
		$result=mysqli_query($db,$query1);




	 ?>
</head>
<body>
	<header>
		<nav>
			<div class="row blank">
	
			</div>
		</nav>
					
		<div class="cont">
				<form method="post">
			<?php echo "<h3><br>Hey $name , Select a course</h3><br>"; ?>

			<?php
			if($result)
			{	
				while($arr=mysqli_fetch_row($result))
				{	
					$cd=$arr['1'];
					$course=$arr['2'];
				echo "$cd - $course <input type='radio' name='choice' value='$cd'><br>";

					}
				}

			 ?>
		
			<input type="submit" name="add" class="btn1" value="Continue">
					
		<?php

		$continue = @$_POST['add'];
		$choice = @$_POST['choice'];

		if($continue)

		{
		if ($choice) {
		$_SESSION['choice']=$choice;
		header( "refresh:0; url=tail.php" ); 
		exit();
	}
	else
	{
		echo "<br><font size='2px' color='#aa00'>Enter an input</font>";
	}

		}
	?>





		</div>

			</form>
			<form method="post" class ="main_nav">

      		<input type="submit" name="home" class="btn1" value="Home">
			<input type="submit" class="btn1" name="logout" value="Logout">
		<?php

		$home = @$_POST['home'];
		$logout = @$_POST['logout'];

		if($home)
		{
		header("location:logout.php"); 
		exit();

		}
		if($logout)
		{
		session_destroy();
		header("location:index.php"); 
		exit();
		}
	?>
			
			</form>
		
	</header>
</d>
</body>
</html>

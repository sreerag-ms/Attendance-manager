<html>
<head>
	<link rel="stylesheet" type="text/css" href="style1.css">
	<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro|Play" rel="stylesheet">
<title>Sign UP</title>

<?php
include('db.php');
$fullname = @$_POST['fullname'];
$username = @$_POST['username'];
$password = @$_POST['pass'];
$cpassword=@$_POST['c_pass'];
$submit = @$_POST['submit'];
function alert(){

echo "<script type='text/javascript'>";
echo "alert('Succssfully registered..');";
echo "</script>";

}
if ($submit)
  # code..
if($fullname)
  if ($username)
    if ($password)
        if($password==$cpassword)
          if (strlen($fullname)<20) 
            if(strlen($username)<10)
              if(strlen($password)<15 || strlen($password)>5){
                if (preg_match("#[0-9]+#", $password) && (preg_match("#[a-zA-Z]+#", $password))) {
                $insert=mysqli_query($db,"INSERT INTO users(fullname,username,password) VALUES('$fullname','$username','$password')") or die("COULDNT INSERT");
                if ($insert) {
                  # code...
                alert();
                header( "refresh:0; url=index.php" );
                exit();
                }
                else
                  echo "Registration failed";
                }
                else
                  echo "Password Weak";
              }
              else
                echo "Password length should be <10 and >5 ";
            else
              echo "Enter small username";
          else
            echo "Enter a smaller name";
        else
          echo "Password donot match";
    else
      echo "Please Enter a Password<br>"; 
  else    
    echo "Please Enter a User ID<br>";
else
    echo "Please Enter a Fullname<br>";
  

?>


</head>
<body>
	<header>
		<nav>
			<div class="row blank">
	
			</div>
		</nav>
		<div class="cont">
		
			<form method="post" class ="form">
				<h3>Sign Up</h3>
			<input class="txt" type="text"  name="fullname" placeholder="Enter fullname"><br>
      <input class="txt" type="text" name="username" placeholder="Enter User ID"><br>
      <input class="txt" type="password" name="pass" placeholder="Enter password"><br>
      <input class="txt" type="password" name="c_pass" placeholder="Confirm password"><br>
      
			<input type="submit" class="btn1" name="submit" value="Signup">
			
			</form>
		</div>
	</header>
</d>
</body>
</html>

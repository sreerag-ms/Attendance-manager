<?php
$mysql_hostname = "127.0.0.1";
$mysql_username = "root";
$mysql_password = "";
$mysql_database = "login";
$db=mysqli_connect($mysql_hostname,$mysql_username,$mysql_password,$mysql_database) or die("something went wrong");
mysqli_select_db($db,"login") or die("couldnt find");



?>

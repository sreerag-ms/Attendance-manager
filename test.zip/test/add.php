<html>
<head>
	<link rel="stylesheet" type="text/css" href="styleadd.css">
	<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro|Play" rel="stylesheet">
<title>Sign UP</title>

<?php
include('db.php');
session_start();
$id=(int)$_SESSION['id'];
#var_dump($id);

include('db.php');
$code = @$_POST['code'];
$coursename = @$_POST['coursename'];
$submit = @$_POST['submit'];
$query2 = "INSERT INTO data(id,code,coursename) VALUES($id,'$code','$coursename')";
function alert(){

echo "<script type='text/javascript'>";
echo "alert('Course succssfully registered..');";
echo "</script>";

}
if ($submit)
  # code..
if($code)
  if ($coursename)
  {
    $insert = mysqli_query($db,$query2) or die("FAILED");
    if ($insert)
    {
    alert();
    header( "refresh:0; url=logout.php" );
    exit();
    }
    else
        echo "Registration failed";
  }	
  else    
    echo "Please Enter a coursename<br>";
else
    echo "Please Enter a Course code<br>";
  

?>


</head>
<body>
	<header>
		<nav>
			<div class="row blank">
	
			</div>
		</nav>
		<div class="cont">
		
			<form method="post" class ="form">
				<h3><br>Course</h3>
		<input class="txt" type="text"  name="code" placeholder="Enter course code"><br>
      	<input class="txt" type="text" name="coursename" placeholder="Enter course name"><br>
      
			<input type="submit" class="btn1" name="submit" value="Register">
			
			</form>
		</div>

		</div>

			</form>
			<form method="post" class ="main_nav">

      		<input type="submit" name="home" class="btn1" value="Home">
			<input type="submit" class="btn1" name="logout" value="Logout">
		<?php

		$home = @$_POST['home'];
		$logout = @$_POST['logout'];

		if($home)
		{
		header("location:logout.php"); 
		exit();

		}
		if($logout)
		{
		session_destroy();
		header("location:index.php"); 
		exit();
		}
	?>
			
			</form>
	</header>
</d>
</body>
</html>

<html>
<head>
	<?php
	include('db.php');
	$id = @$_POST['id'];
	$pass = @$_POST['pass'];
	$submit = @$_POST['submit'];

if($submit)
	if($id)
		if($pass)
			{	#$sessiion
				$sql="SELECT id,username,fullname,password FROM users WHERE username='$id'";
				if ($result=mysqli_query($db,$sql))
  					{
              $flag=1;
  						while($row = mysqli_fetch_array($result)) {
  							$flag=1;
  							if ($row["password"]==$pass) {
  								$flag=0;
                  session_start();
  								$_SESSION['fullname'] = $row['fullname'];
  								$_SESSION['id'] = $row['id'];
                  				
  								  header("Location:logout.php");
  								  exit();

  								# code...
  							}
  							
  								
  							# code...
  						}
  						if ($flag==1) {
  							# code...
  							echo "<font color='red'>Invalid Username or password</font>";

  						}
  					}

  					else{
  						echo "aaa<font color='red'>Invalid Username</font>";
            }

			}
		else
			echo "Enter password";
	else
		echo "Enter User ID";
  if (@$_POST['sub2']) {

    # code...
    header("Location:register.php");
    exit();
  }

	?>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Titillium+Web">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Maven+Pro|Play" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Maven+Pro" rel="stylesheet">

<title>Login</title>
</head>
<body>
	<header>
		<nav>
			<div class="row blank">
	
			</div>
		</nav>
		<div class="cont">
		
			<form method="post" class ="form">
				<h3>Login</h3>
			<input class="txt" type="text" name="id" placeholder="Enter User ID"><br>
			<input class="txt" type="password" name="pass" placeholder="Enter password"><br>
			<input type="submit" class="btn1" name="submit" value="Login">
      <input type="submit" class="btn" name="sub2" value="Register">

			
			</form>
		</div>
	</header>
</d>
</body>
</html>
